# curso_programacion_bash_platzi
Repositorio para el Curso de Programación Bash de Platzi
